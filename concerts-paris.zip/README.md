# Concerts à Paris

Chaque lundi matin, GitHub lit vos favoris Deezer, cherche les concerts à venir à Paris,
repère vos artistes et propose des découvertes proches de vos goûts. Le résultat est publié
sur un site privé : bandeau des annonces de la semaine, calendrier, liste, vos artistes, salles.

## Mise en place (c. 30 minutes, une seule fois)

### 1. Créer le dépôt GitHub

Créez un dépôt **privé** nommé `concerts-paris`, puis envoyez-y le contenu de ce dossier.
Sur Mac, le Finder masque le dossier `.github` : l'envoi par glisser-déposer sur le site GitHub
l'oublie. Passez plutôt par le Terminal :

```bash
cd chemin/vers/concerts-paris
git init -b main
git add .
git commit -m "Version initiale"
git remote add origin https://github.com/VOTRE-COMPTE/concerts-paris.git
git push -u origin main
```

(ou par l'application GitHub Desktop, qui envoie bien les dossiers masqués).

### 2. Obtenir une clé Ticketmaster (gratuite)

Créez un compte sur https://developer.ticketmaster.com, ouvrez « My Apps » et copiez la
« Consumer Key ». Dans le dépôt GitHub : **Settings > Secrets and variables > Actions >
New repository secret**, nom `TICKETMASTER_API_KEY`, valeur : la clé.

Sans cette clé, le site fonctionne avec les seules sources sans clé (Que faire à Paris,
pages des salles), donc avec beaucoup moins de concerts et quasiment aucune découverte.

### 3. Bandsintown (facultatif)

Bandsintown délivre un identifiant d'application sur demande. Si vous en obtenez un,
ajoutez-le en secret sous le nom `BANDSINTOWN_APP_ID`. Il complète Ticketmaster pour les
petites salles et ajoute les premières parties aux découvertes.

### 4. Premier lancement

Onglet **Actions** du dépôt > « Mise à jour hebdomadaire » > **Run workflow**. Le premier
passage est plus long (c. 5 à 10 minutes) car il lit les artistes similaires de toute votre
liste. Le journal de l'exécution indique ce que chaque source a renvoyé.

Le traitement relance ensuite seul chaque lundi à 5h UTC.

### 5. Publier le site (Cloudflare Pages, gratuit, dépôt privé accepté)

1. Créez un compte sur https://dash.cloudflare.com.
2. Section Workers & Pages : créez une application Pages reliée à votre compte GitHub et
   choisissez le dépôt `concerts-paris` (l'intitulé exact des menus peut varier).
3. Commande de build : laisser vide. Répertoire de sortie : `site`.
4. Cloudflare republie le site à chaque mise à jour du dépôt, donc chaque lundi.

L'adresse obtenue (`concerts-paris-xxx.pages.dev`) n'est référencée nulle part, mais reste
accessible à qui la connaît. Pour la réserver à votre adresse e-mail, activez Cloudflare
Access sur le projet (gratuit jusqu'à 50 utilisateurs).

## Réglages

`config/venues.yaml` : vos salles favorites. Elles sont signalées dans le site, filtrables
(« Vos salles uniquement ») et donnent un léger bonus aux découvertes. Pour une salle absente
des billetteries couvertes, renseignez `agenda_url` avec sa page programme : si la page
publie des données schema.org, ses concerts sont lus directement.

`config/settings.yaml` : identifiant Deezer, rayon autour de Paris, pondérations du score
d'affinité, seuil des découvertes.

Après modification, relancez le traitement depuis l'onglet Actions pour voir l'effet tout de suite.

## Comment les concerts sont retenus

**Vos artistes.** Chaque artiste reçoit un score : 5 points s'il est en favori, 2 par album
liké, 1 par titre liké, 0,25 par titre présent dans vos playlists. Niveau 1 à partir de 5
points, niveau 2 à partir de 2, niveau 3 en dessous. Un concert est retenu quand le nom d'un
de vos artistes figure dans la programmation, ou, pour les sources sans programmation
détaillée, dans le titre (repéré « à vérifier » sur la fiche).

**Découvertes.** Pour chaque artiste inconnu programmé à Paris, le script compare ses
« artistes similaires » Deezer à votre liste, et regarde aussi si vos artistes favoris le citent
parmi leurs similaires. La fiche indique de qui il est proche. Le script analyse 200 nouveaux
artistes par semaine au plus, en commençant par vos salles favorites ; le cache s'accumule,
la couverture s'élargit donc au fil des semaines.

**Votre liste ne fait que grandir.** Un artiste retiré de vos favoris reste suivi, signalé
« Retiré de vos favoris » dans l'onglet Mes artistes. Pour l'oublier, supprimez sa ligne dans
`data/artists.json`.

## Limites connues

- Homonymes : un nom court ou courant (« Air », « Justice ») peut rattacher un concert d'un
  autre artiste. Les rapprochements sur le titre seul exigent au moins 4 caractères.
- Couverture : les concerts vendus uniquement par Fnac Spectacles, See Tickets, Dice ou
  Shotgun n'apparaissent que si la salle est configurée avec une `agenda_url` lisible.
- Les sites de salles changent de structure sans prévenir : une salle qui ne renvoie plus
  rien apparaît avec 0 événement dans le journal du traitement.

## Tester sur votre ordinateur

```bash
pip install -r requirements.txt
export TICKETMASTER_API_KEY=votre_cle
python -m src.main
python -m http.server 8000 -d site    # puis ouvrir http://localhost:8000
```
