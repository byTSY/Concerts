"""Écrit les fichiers lus par le site : concerts, artistes, salles, informations de mise à jour."""
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone

from .util import DATA, SITE_DATA, load_json, log, save_json, today_iso

KEEP = ("id", "title", "date", "time", "venue", "venue_favorite", "address", "city", "price", "on_sale",
        "status", "genre", "image", "links", "artists", "description")


def build(events, artists, source_status):
    today = today_iso()
    new_limit = (date.today() - timedelta(days=7)).isoformat()
    previous = {e["id"]: e for e in load_json(DATA / "events.json", [])}

    out, venues = [], defaultdict(lambda: {"total": 0, "known": 0, "discovery": 0, "favorite": False})
    for ev in events:
        v = venues[ev["venue"]]
        v["total"] += 1
        v["favorite"] = v["favorite"] or ev.get("venue_favorite", False)

        if ev.get("matched"):
            kind = "known"
        elif ev.get("discovery"):
            kind = "discovery"
        else:
            continue
        v[kind] += 1

        item = {k: ev.get(k) for k in KEEP}
        item["kind"] = kind
        if kind == "known":
            item["tier"] = ev["matched"][0]["tier"]
            item["matched"] = [{"name": m["name"], "tier": m["tier"], "via": m["via"],
                                "link": (artists.get(m["id"]) or {}).get("link")} for m in ev["matched"]]
        else:
            item["discovery"] = ev["discovery"]
        item["first_seen"] = previous.get(ev["id"], {}).get("first_seen", today)
        item["is_new"] = item["first_seen"] >= new_limit
        out.append(item)

    out.sort(key=lambda e: (e["date"], e.get("time") or ""))
    save_json(DATA / "events.json", out)
    save_json(SITE_DATA / "events.json", out)

    venue_list = [{"name": n, **s} for n, s in venues.items()]
    venue_list.sort(key=lambda v: (-(v["known"] + v["discovery"]), -v["total"], v["name"]))
    save_json(SITE_DATA / "venues.json", venue_list)

    site_artists = sorted(
        ({k: a.get(k) for k in ("name", "link", "picture", "score", "tier", "first_seen", "still_liked", "sources")}
         for a in artists.values()),
        key=lambda a: (-a["score"], a["name"].lower()))
    save_json(SITE_DATA / "artists.json", site_artists)

    meta = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="minutes"),
        "sources": source_status,
        "counts": {
            "artists": len(artists),
            "new_artists": sum(1 for a in artists.values() if a.get("first_seen") == today),
            "known": sum(1 for e in out if e["kind"] == "known"),
            "discovery": sum(1 for e in out if e["kind"] == "discovery"),
            "new_events": sum(1 for e in out if e["is_new"]),
        },
    }
    save_json(SITE_DATA / "meta.json", meta)
    log(f"Site : {meta['counts']['known']} concerts de vos artistes, "
        f"{meta['counts']['discovery']} découvertes, {meta['counts']['new_events']} nouveautés")
